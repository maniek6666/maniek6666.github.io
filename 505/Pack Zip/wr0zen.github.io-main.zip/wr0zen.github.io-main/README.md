# wr0zen.github.io
Yet Another Exploit Host!

<a href="https://wr0zen.github.io/phwoar/index.html">5.05</a> <a href="https://wr0zen.github.io/phive/index.html">6.72</a> <a href="https://wr0zen.github.io/baikal/index.html">Linux 6.72 (Baikal)</a> <br> <a href="https://wr0zen.github.io/leeful900/index.html">9.00</a>


